window.VIP_MASCOT_USERNAMES = {
  pink: ["username1"],
  blue: ["username2"],
  green: ["username3"],
  mint: ["username4"],
  orange: ["username5"],
  purple: ["username6"],
  red: ["username7"],
  sky: ["username8"],
  yellow: ["username9"]
};

window.VIP_MASCOT_STREAMERBOT = {
  enabled: true,
  url: "ws://127.0.0.1:8080/"
};
