(() => {
  const config = window.VIP_MASCOT_CONFIG || {};
  const usernameConfig = window.VIP_MASCOT_USERNAMES || {};
  const streamerBotConfig = window.VIP_MASCOT_STREAMERBOT || {};
  const portal = document.getElementById("portal");
  const bear = document.getElementById("bear");
  const queue = [];
  const recentQueuedUsers = new Map();
  let running = false;
  let loopActive = false;
  let loopTimer = null;
  let loopStopTimer = null;
  let portalShown = false;
  let portalHideTimer = null;

  const defaults = {
    portal: { src: "", left: 40, bottom: 40, width: 210, hideAfterMs: 12 * 60 * 60 * 1000 },
    bear: { bottom: 72, width: 150, startX: 78, cozyX: 315 },
    queue: { maxSize: 5, duplicateWindowMs: 30000 },
    timing: { sequenceScale: 1, loopEveryMs: 45 * 60 * 1000, stopAfterMs: 12 * 60 * 60 * 1000 },
    assignments: {},
    bears: {}
  };

  const settings = {
    portal: { ...defaults.portal, ...(config.portal || {}) },
    bear: { ...defaults.bear, ...(config.bear || {}) },
    queue: { ...defaults.queue, ...(config.queue || {}) },
    timing: { ...defaults.timing, ...(config.timing || {}) },
    assignments: config.assignments || {},
    bears: config.bears || {}
  };

  function normalizeUserName(name) {
    return String(name || "").trim().toLowerCase();
  }

  Object.entries(usernameConfig).forEach(([bearKey, usernames]) => {
    [].concat(usernames || []).forEach((username) => {
      const user = normalizeUserName(username);
      if (user) settings.assignments[user] = bearKey;
    });
  });

  function wait(ms) {
    const scaled = Math.max(16, Math.round(ms * settings.timing.sequenceScale));
    return new Promise((resolve) => window.setTimeout(resolve, scaled));
  }

  function setPose(src) {
    if (src && bear.src !== src) bear.src = src;
  }

  function setMoveSpeed(ms) {
    bear.style.setProperty("--bear-move-ms", `${ms}ms`);
  }

  function moveTo(x, y = 0, scale = 1, rotate = 0, duration = 1600) {
    setMoveSpeed(duration);
    bear.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${scale}) rotate(${rotate}deg)`;
  }

  async function glideTo(x, y = 0, scale = 1, rotate = 0, duration = 1600) {
    moveTo(x, y, scale, rotate, duration);
    await wait(duration);
  }

  async function swapPose(src, pauseMs = 500) {
    setPose(src);
    await wait(pauseMs);
  }

  async function holdPose(src, pauseMs) {
    setPose(src);
    await wait(pauseMs);
  }

  async function showBear(poses) {
    setPose(poses.idle);
    moveTo(settings.bear.startX, 10, 0.84, -1, 1);
    bear.classList.add("is-visible");
    await wait(700);
  }

  async function hideBear() {
    bear.classList.remove("is-visible");
    await wait(650);
  }

  function showPortalOnce() {
    if (portalShown) return;
    portalShown = true;
    portal.src = settings.portal.src;
    portal.style.setProperty("--portal-left", `${settings.portal.left}px`);
    portal.style.setProperty("--portal-bottom", `${settings.portal.bottom}px`);
    portal.style.setProperty("--portal-width", `${settings.portal.width}px`);
    portal.classList.add("is-visible");

    if (settings.portal.hideAfterMs > 0) {
      window.clearTimeout(portalHideTimer);
      portalHideTimer = window.setTimeout(() => {
        portal.classList.remove("is-visible");
      }, settings.portal.hideAfterMs);
    }
  }

  function applyLayout() {
    bear.style.setProperty("--bear-bottom", `${settings.bear.bottom}px`);
    bear.style.setProperty("--bear-width", `${settings.bear.width}px`);
    moveTo(settings.bear.startX, 0, 0.9, 0, 1);
  }

  function getBearForUser(username) {
    const key = settings.assignments[normalizeUserName(username)];
    if (!key) return null;
    return settings.bears[key] || null;
  }

  function preloadAssets() {
    const urls = new Set([settings.portal.src]);
    Object.values(settings.bears).forEach((poses) => {
      Object.values(poses).forEach((src) => urls.add(src));
    });
    urls.forEach((src) => {
      if (!src) return;
      const image = new Image();
      image.src = src;
      if (image.decode) image.decode().catch(() => {});
    });
  }

  function enqueueVip(username) {
    const user = normalizeUserName(username);
    const poses = getBearForUser(user);
    if (!user || !poses) return false;

    const now = Date.now();
    const duplicateUntil = recentQueuedUsers.get(user) || 0;
    const alreadyQueued = queue.some((item) => item.user === user);
    if (alreadyQueued || now < duplicateUntil) return false;
    if (queue.length >= settings.queue.maxSize) return false;

    recentQueuedUsers.set(user, now + settings.queue.duplicateWindowMs);
    queue.push({ user, poses });
    processQueue();
    return true;
  }

  function enqueueVipLoopRun(username) {
    const user = normalizeUserName(username);
    const poses = getBearForUser(user);
    if (!user || !poses || queue.length >= settings.queue.maxSize) return false;

    queue.push({ user, poses });
    processQueue();
    return true;
  }

  async function runBearSequence(poses) {
    showPortalOnce();
    await showBear(poses);

    setPose(poses.walkRight);
    await glideTo(settings.bear.cozyX, -4, 1, 1, 4200);

    await holdPose(poses.idle, 3200);
    await swapPose(poses.blink, 650);
    await holdPose(poses.idle, 1800);
    await swapPose(poses.love, 3600);
    await holdPose(poses.idle, 2200);
    await swapPose(poses.sleepy, 3400);

    setPose(poses.walkLeft);
    await glideTo(settings.bear.startX, 10, 0.84, -1, 3800);

    await hideBear();
  }

  async function processQueue() {
    if (running) return;
    running = true;

    while (queue.length) {
      const item = queue.shift();
      try {
        await runBearSequence(item.poses);
      } catch (error) {
        console.error("VIP mascot sequence failed:", error);
      }
      await wait(500 + Math.random() * 1200);
    }

    running = false;
  }

  function stopVipLoop() {
    loopActive = false;
    window.clearInterval(loopTimer);
    window.clearTimeout(loopStopTimer);
  }

  function activateVipLoop(username) {
    if (loopActive) return;
    const user = normalizeUserName(username) || Object.keys(settings.assignments)[0];
    if (!user) return;

    loopActive = true;
    enqueueVipLoopRun(user);

    loopTimer = window.setInterval(() => {
      enqueueVipLoopRun(user);
    }, settings.timing.loopEveryMs);

    loopStopTimer = window.setTimeout(() => {
      stopVipLoop();
      portal.classList.remove("is-visible");
    }, settings.timing.stopAfterMs);
  }

  function getStreamerBotChatUser(payload) {
    const source = String(payload?.event?.source || "").toLowerCase();
    const type = String(payload?.event?.type || "").toLowerCase();
    const data = payload?.data || {};
    if (source !== "twitch") return "";
    if (!(type === "chatmessage" || type === "message" || type === "firstword" || type === "firstwords")) return "";

    return (
      data.user_login ||
      data.user_name ||
      data.display_name ||
      data.user?.login ||
      data.user?.name ||
      data.user?.displayName ||
      data.message?.user?.login ||
      data.message?.user?.name ||
      data.message?.user?.displayName ||
      (typeof data.user === "string" ? data.user : "")
    );
  }

  function connectStreamerBot() {
    if (streamerBotConfig.enabled === false) return;
    const url = streamerBotConfig.url || "ws://127.0.0.1:8080/";

    try {
      const socket = new WebSocket(url);

      socket.onopen = () => {
        socket.send(JSON.stringify({
          request: "Subscribe",
          events: {
            Twitch: ["ChatMessage", "FirstWord"]
          },
          id: "cozy-vip-mascot-widget"
        }));
      };

      socket.onmessage = (message) => {
        try {
          const payload = JSON.parse(message.data);
          const username = getStreamerBotChatUser(payload);
          if (username) enqueueVip(username);
        } catch (error) {
          console.error("VIP mascot Streamer.bot message failed:", error);
        }
      };

      socket.onerror = (error) => {
        console.error("VIP mascot Streamer.bot WebSocket error:", error);
      };

      socket.onclose = () => {
        window.setTimeout(connectStreamerBot, 5000);
      };
    } catch (error) {
      console.error("VIP mascot Streamer.bot connection failed:", error);
      window.setTimeout(connectStreamerBot, 5000);
    }
  }

  applyLayout();
  preloadAssets();

  connectStreamerBot();
  window.vipMascotSeen = enqueueVip;
  window.vipMascotActivateLoop = activateVipLoop;
  window.vipMascotStopLoop = stopVipLoop;
  window.vipMascotRunTest = () => {
    const firstUser = Object.keys(settings.assignments)[0];
    if (firstUser) enqueueVip(firstUser);
  };
})();
