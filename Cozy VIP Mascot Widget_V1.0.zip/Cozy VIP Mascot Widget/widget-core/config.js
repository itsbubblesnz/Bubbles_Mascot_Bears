window.VIP_MASCOT_CONFIG = {
  portal: {
    src: "./assets/portal/Bear Door.png",
    left: 40,
    bottom: 40,
    width: 210,
    hideAfterMs: 12 * 60 * 60 * 1000
  },

  bear: {
    bottom: 72,
    width: 150,
    startX: 78,
    cozyX: 315
  },

  queue: {
    maxSize: 5,
    duplicateWindowMs: 30000
  },

  timing: {
    sequenceScale: 1,
    loopEveryMs: 45 * 60 * 1000,
    stopAfterMs: 12 * 60 * 60 * 1000
  },

  assignments: {
    username1: "pink",
    username2: "blue",
    username3: "green",
    username4: "mint",
    username5: "orange",
    username6: "purple",
    username7: "red",
    username8: "sky",
    username9: "yellow"
  },

  bears: {
    pink: {
      idle: "./assets/bears/pink_idle.png",
      blink: "./assets/bears/pink_blink.png",
      love: "./assets/bears/pink_love.png",
      wink: "./assets/bears/pink_wink.png",
      jump: "./assets/bears/pink_jump.png",
      sleepy: "./assets/bears/pink_sleepy.png",
      wave: "./assets/bears/pink_wave.png",
      walkRight: "./assets/bears/pink_right.png",
      walkLeft: "./assets/bears/pink_left.png"
    },

    blue: {
      idle: "./assets/bears/blue_idle.png",
      blink: "./assets/bears/blue_blink.png",
      love: "./assets/bears/blue_love.png",
      wink: "./assets/bears/blue_wink.png",
      jump: "./assets/bears/blue_jump.png",
      sleepy: "./assets/bears/blue_sleepy.png",
      wave: "./assets/bears/blue_wave.png",
      walkRight: "./assets/bears/blue_right.png",
      walkLeft: "./assets/bears/blue_left.png"
    },

    green: {
      idle: "./assets/bears/green_idle.png",
      blink: "./assets/bears/green_blink.png",
      love: "./assets/bears/green_love.png",
      wink: "./assets/bears/green_wink.png",
      jump: "./assets/bears/green_jump.png",
      sleepy: "./assets/bears/green_sleepy.png",
      wave: "./assets/bears/green_wave.png",
      walkRight: "./assets/bears/green_right.png",
      walkLeft: "./assets/bears/green_left.png"
    },

    mint: {
      idle: "./assets/bears/mint_idle.png",
      blink: "./assets/bears/mint_blink.png",
      love: "./assets/bears/mint_love.png",
      wink: "./assets/bears/mint_wink.png",
      jump: "./assets/bears/mint_jump.png",
      sleepy: "./assets/bears/mint_sleepy.png",
      wave: "./assets/bears/mint_wave.png",
      walkRight: "./assets/bears/mint_right.png",
      walkLeft: "./assets/bears/mint_left.png"
    },

    orange: {
      idle: "./assets/bears/orange_idle.png",
      blink: "./assets/bears/orange_blink.png",
      love: "./assets/bears/orange_love.png",
      wink: "./assets/bears/orange_wink.png",
      jump: "./assets/bears/orange_jump.png",
      sleepy: "./assets/bears/orange_sleepy.png",
      wave: "./assets/bears/orange_wave.png",
      walkRight: "./assets/bears/orange_right.png",
      walkLeft: "./assets/bears/orange_left.png"
    },

    purple: {
      idle: "./assets/bears/purple_idle.png",
      blink: "./assets/bears/purple_blink.png",
      love: "./assets/bears/purple_love.png",
      wink: "./assets/bears/purple_wink.png",
      jump: "./assets/bears/purple_jump.png",
      sleepy: "./assets/bears/purple_sleepy.png",
      wave: "./assets/bears/purple_wave.png",
      walkRight: "./assets/bears/purple_right.png",
      walkLeft: "./assets/bears/purple_left.png"
    },

    red: {
      idle: "./assets/bears/red_idle.png",
      blink: "./assets/bears/red_blink.png",
      love: "./assets/bears/red_love.png",
      wink: "./assets/bears/red_wink.png",
      jump: "./assets/bears/red_jump.png",
      sleepy: "./assets/bears/red_sleepy.png",
      wave: "./assets/bears/red_wave.png",
      walkRight: "./assets/bears/red_right.png",
      walkLeft: "./assets/bears/red_left.png"
    },

    sky: {
      idle: "./assets/bears/sky_idle.png",
      blink: "./assets/bears/sky_blink.png",
      love: "./assets/bears/sky_love.png",
      wink: "./assets/bears/sky_wink.png",
      jump: "./assets/bears/sky_jump.png",
      sleepy: "./assets/bears/sky_sleepy.png",
      wave: "./assets/bears/sky_wave.png",
      walkRight: "./assets/bears/sky_right.png",
      walkLeft: "./assets/bears/sky_left.png"
    },

    yellow: {
      idle: "./assets/bears/yellow_idle.png",
      blink: "./assets/bears/yellow_blink.png",
      love: "./assets/bears/yellow_love.png",
      wink: "./assets/bears/yellow_wink.png",
      jump: "./assets/bears/yellow_jump.png",
      sleepy: "./assets/bears/yellow_sleepy.png",
      wave: "./assets/bears/yellow_wave.png",
      walkRight: "./assets/bears/yellow_right.png",
      walkLeft: "./assets/bears/yellow_left.png"
    }
  }
};
